package entity;

import jakarta.persistence.*;

@Entity
@jakarta.persistence.Table(name = "inhouse_part", schema = "inventory_manager", catalog = "postgres")
public class InhousePartEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @jakarta.persistence.Column(name = "part_id")
    private int partId;

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    @Basic
    @Column(name = "machine_id")
    private int machineId;

    public int getMachineId() {
        return machineId;
    }

    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InhousePartEntity that = (InhousePartEntity) o;

        if (partId != that.partId) return false;
        if (machineId != that.machineId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = partId;
        result = 31 * result + machineId;
        return result;
    }
}
