package entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
@jakarta.persistence.Table(name = "inventory_part", schema = "inventory_manager", catalog = "postgres")
@jakarta.persistence.IdClass(entity.InventoryPartEntityPK.class)
public class InventoryPartEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @jakarta.persistence.Column(name = "inventory_id")
    private int inventoryId;

    public int getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @jakarta.persistence.Column(name = "part_id")
    private int partId;

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InventoryPartEntity that = (InventoryPartEntity) o;

        if (inventoryId != that.inventoryId) return false;
        if (partId != that.partId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = inventoryId;
        result = 31 * result + partId;
        return result;
    }
}
