package entity;

import java.io.Serializable;

public class InventoryPartEntityPK implements Serializable {
}
